package com.placacontrol.app;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.hoho.android.usbserial.driver.UsbSerialDriver;
import com.hoho.android.usbserial.driver.UsbSerialPort;
import com.hoho.android.usbserial.driver.UsbSerialProber;
import com.hoho.android.usbserial.util.SerialInputOutputManager;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * PlacaControl: USB serial controller + sketch editor for Arduino and ESP32.
 * Automatic GPIO control requires the supplied PlacaControl firmware to be flashed first.
 */
public class MainActivity extends Activity {
    private static final String ACTION_USB_PERMISSION = "com.placacontrol.app.USB_PERMISSION";
    private static final int REQUEST_OPEN_FILE = 1001;
    private static final int REQUEST_SAVE_FILE = 1002;
    private static final int BG = Color.rgb(10, 16, 30);
    private static final int PANEL = Color.rgb(20, 30, 49);
    private static final int PANEL2 = Color.rgb(28, 41, 64);
    private static final int TEXT = Color.rgb(235, 243, 255);
    private static final int MUTED = Color.rgb(159, 177, 202);
    private static final int ACCENT = Color.rgb(54, 211, 153);
    private static final int BLUE = Color.rgb(72, 141, 255);

    private UsbManager usbManager;
    private final List<UsbSerialDriver> drivers = new ArrayList<>();
    private UsbSerialDriver waitingDriver;
    private UsbDeviceConnection usbConnection;
    private UsbSerialPort serialPort;
    private SerialInputOutputManager serialIoManager;
    private boolean receiverRegistered = false;

    private Spinner boardSpinner;
    private Spinner deviceSpinner;
    private Spinner baudSpinner;
    private TextView connectionStatus;
    private TextView deviceSummary;
    private TextView serialLog;
    private ScrollView serialLogScroll;
    private EditText commandInput;
    private EditText pinInput;
    private EditText valueInput;
    private EditText sketchEditor;
    private Button connectButton;

    private final BroadcastReceiver usbPermissionReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!ACTION_USB_PERMISSION.equals(intent.getAction())) return;
            boolean granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false);
            UsbSerialDriver requested = waitingDriver;
            waitingDriver = null;
            if (granted && requested != null) {
                openDriver(requested);
            } else {
                toast("Android no concedió permiso USB. Vuelve a intentar.");
                setDisconnectedStatus();
            }
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        usbManager = (UsbManager) getSystemService(Context.USB_SERVICE);
        registerUsbReceiver();
        buildUi();
        refreshDrivers();
    }

    private void registerUsbReceiver() {
        IntentFilter filter = new IntentFilter(ACTION_USB_PERMISSION);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(usbPermissionReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(usbPermissionReceiver, filter);
        }
        receiverRegistered = true;
    }

    private void buildUi() {
        ScrollView outerScroll = new ScrollView(this);
        outerScroll.setFillViewport(true);
        outerScroll.setBackgroundColor(BG);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16), dp(18), dp(16), dp(26));
        outerScroll.addView(page);

        TextView title = text("PlacaControl", 29, TEXT, true);
        page.addView(title);
        TextView subtitle = text("Control por USB • Arduino + ESP32", 14, MUTED, false);
        LinearLayout.LayoutParams subtitleLp = params(-1, -2); subtitleLp.topMargin = dp(3);
        page.addView(subtitle, subtitleLp);
        TextView scope = text("USB OTG · Monitor serie · Pines · Editor .ino", 12, ACCENT, true);
        LinearLayout.LayoutParams scopeLp = params(-1, -2); scopeLp.topMargin = dp(8); scopeLp.bottomMargin = dp(16);
        page.addView(scope, scopeLp);

        LinearLayout connectionPanel = panel();
        page.addView(connectionPanel, sectionParams());
        connectionPanel.addView(sectionTitle("1. Conexión USB"));
        connectionPanel.addView(label("Familia de placa"));
        boardSpinner = spinner(new String[]{
                "Arduino UNO / Nano",
                "Arduino Mega",
                "ESP32 DevKit / WROOM",
                "ESP32-CAM (experimental)"
        });
        connectionPanel.addView(boardSpinner, fieldParams());
        connectionPanel.addView(label("Dispositivo USB detectado"));
        deviceSpinner = spinner(new String[]{"Buscando placas…"});
        connectionPanel.addView(deviceSpinner, fieldParams());
        connectionPanel.addView(label("Velocidad serie"));
        baudSpinner = spinner(new String[]{"9600", "19200", "38400", "57600", "115200", "230400", "460800"});
        baudSpinner.setSelection(4);
        connectionPanel.addView(baudSpinner, fieldParams());

        LinearLayout connectionButtons = row();
        connectButton = button("Conectar", ACCENT, BG);
        connectButton.setOnClickListener(v -> connectSelectedDevice());
        Button refreshButton = button("Buscar USB", BLUE, Color.WHITE);
        refreshButton.setOnClickListener(v -> refreshDrivers());
        Button disconnectButton = button("Desconectar", Color.rgb(97, 111, 133), Color.WHITE);
        disconnectButton.setOnClickListener(v -> disconnectSerial("Desconectado"));
        connectionButtons.addView(connectButton, weightParams());
        connectionButtons.addView(refreshButton, weightParams());
        connectionButtons.addView(disconnectButton, weightParams());
        LinearLayout.LayoutParams buttonsLp = params(-1, -2); buttonsLp.topMargin = dp(8);
        connectionPanel.addView(connectionButtons, buttonsLp);
        connectionStatus = text("Estado: sin conectar", 13, MUTED, true);
        LinearLayout.LayoutParams statusLp = params(-1, -2); statusLp.topMargin = dp(10);
        connectionPanel.addView(connectionStatus, statusLp);
        deviceSummary = text("Conecta la placa con un cable USB de datos y un adaptador OTG compatible.", 12, MUTED, false);
        LinearLayout.LayoutParams summaryLp = params(-1, -2); summaryLp.topMargin = dp(4);
        connectionPanel.addView(deviceSummary, summaryLp);

        LinearLayout controls = panel(); page.addView(controls, sectionParams());
        controls.addView(sectionTitle("2. Control rápido de pines"));
        controls.addView(text("Primero carga el firmware PlacaControl suministrado. Escribe el número del pin según tu placa.", 12, MUTED, false));
        LinearLayout pinRow = row();
        pinInput = field("Pin (ej. 13 o 2)", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
        pinInput.setText("13");
        valueInput = field("Valor 0–255", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
        valueInput.setText("255");
        pinRow.addView(pinInput, weightParams()); pinRow.addView(valueInput, weightParams());
        LinearLayout.LayoutParams pinRowLp = params(-1, -2); pinRowLp.topMargin = dp(6);
        controls.addView(pinRow, pinRowLp);

        LinearLayout modes = row();
        Button modeIn = button("Modo ENTRADA", PANEL2, TEXT);
        modeIn.setOnClickListener(v -> sendPinCommand("MODE " + readPin() + " IN"));
        Button modeOut = button("Modo SALIDA", PANEL2, TEXT);
        modeOut.setOnClickListener(v -> sendPinCommand("MODE " + readPin() + " OUT"));
        Button readDigital = button("Leer digital", PANEL2, TEXT);
        readDigital.setOnClickListener(v -> sendPinCommand("READ " + readPin()));
        modes.addView(modeIn, weightParams()); modes.addView(modeOut, weightParams()); modes.addView(readDigital, weightParams());
        LinearLayout.LayoutParams modesLp = params(-1, -2); modesLp.topMargin = dp(8); controls.addView(modes, modesLp);

        LinearLayout actions = row();
        Button high = button("ENCENDER", ACCENT, BG);
        high.setOnClickListener(v -> sendPinCommand("WRITE " + readPin() + " 1"));
        Button low = button("APAGAR", Color.rgb(255, 180, 85), BG);
        low.setOnClickListener(v -> sendPinCommand("WRITE " + readPin() + " 0"));
        Button analog = button("Leer analógico", PANEL2, TEXT);
        analog.setOnClickListener(v -> sendPinCommand("ANALOG " + readPin()));
        actions.addView(high, weightParams()); actions.addView(low, weightParams()); actions.addView(analog, weightParams());
        LinearLayout.LayoutParams actionsLp = params(-1, -2); actionsLp.topMargin = dp(8); controls.addView(actions, actionsLp);

        Button pwm = button("Aplicar PWM (0–255)", BLUE, Color.WHITE);
        pwm.setOnClickListener(v -> {
            int value = parseInt(valueInput.getText().toString(), -1);
            if (value < 0 || value > 255) { toast("El valor PWM debe estar entre 0 y 255."); return; }
            sendPinCommand("PWM " + readPin() + " " + value);
        });
        LinearLayout.LayoutParams pwmLp = params(-1, 46); pwmLp.topMargin = dp(8); controls.addView(pwm, pwmLp);
        Button ping = button("Probar comunicación (PING)", PANEL2, TEXT);
        ping.setOnClickListener(v -> sendCommand("PING"));
        LinearLayout.LayoutParams pingLp = params(-1, 44); pingLp.topMargin = dp(7); controls.addView(ping, pingLp);

        LinearLayout terminal = panel(); page.addView(terminal, sectionParams());
        terminal.addView(sectionTitle("3. Monitor serie"));
        serialLogScroll = new ScrollView(this);
        serialLogScroll.setFillViewport(false);
        serialLogScroll.setBackground(round(PANEL2, 12, Color.rgb(44, 63, 90), 1));
        serialLog = text("Listo. Al conectar se mostrarán aquí los mensajes de la placa.\n", 12, Color.rgb(177, 255, 222), false);
        serialLog.setTypeface(Typeface.MONOSPACE);
        serialLog.setPadding(dp(10), dp(9), dp(10), dp(9));
        serialLog.setTextIsSelectable(true);
        serialLogScroll.addView(serialLog);
        terminal.addView(serialLogScroll, params(-1, 190));
        commandInput = field("Comando o texto que quieres enviar…", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        LinearLayout.LayoutParams commandLp = params(-1, 48); commandLp.topMargin = dp(8); terminal.addView(commandInput, commandLp);
        LinearLayout sendRow = row();
        Button send = button("Enviar línea", ACCENT, BG);
        send.setOnClickListener(v -> { String line = commandInput.getText().toString(); if (!line.trim().isEmpty()) { sendCommand(line); commandInput.setText(""); } });
        Button clear = button("Limpiar", PANEL2, TEXT);
        clear.setOnClickListener(v -> serialLog.setText(""));
        sendRow.addView(send, weightParams()); sendRow.addView(clear, weightParams());
        LinearLayout.LayoutParams sendRowLp = params(-1, -2); sendRowLp.topMargin = dp(7); terminal.addView(sendRow, sendRowLp);

        LinearLayout editor = panel(); page.addView(editor, sectionParams());
        editor.addView(sectionTitle("4. Editor de sketches .ino"));
        editor.addView(text("Puedes editar, abrir y guardar archivos. Esta versión no compila ni flashea sketches desde la app; usa ArduinoDroid o Arduino IDE para eso.", 12, MUTED, false));
        LinearLayout editorButtons1 = row();
        Button open = button("Abrir .ino", PANEL2, TEXT); open.setOnClickListener(v -> openSketch());
        Button save = button("Guardar .ino", BLUE, Color.WHITE); save.setOnClickListener(v -> saveSketch());
        editorButtons1.addView(open, weightParams()); editorButtons1.addView(save, weightParams());
        LinearLayout.LayoutParams e1 = params(-1, -2); e1.topMargin = dp(8); editor.addView(editorButtons1, e1);
        LinearLayout editorButtons2 = row();
        Button loadFirmware = button("Cargar firmware de control", ACCENT, BG);
        loadFirmware.setOnClickListener(v -> loadBoardFirmware());
        Button loadExample = button("Ejemplo serie", PANEL2, TEXT);
        loadExample.setOnClickListener(v -> sketchEditor.setText(serialExample()));
        editorButtons2.addView(loadFirmware, weightParams()); editorButtons2.addView(loadExample, weightParams());
        LinearLayout.LayoutParams e2 = params(-1, -2); e2.topMargin = dp(7); editor.addView(editorButtons2, e2);
        sketchEditor = new EditText(this);
        sketchEditor.setTextColor(TEXT); sketchEditor.setHintTextColor(MUTED);
        sketchEditor.setHint("// Escribe aquí tu sketch Arduino o ESP32…");
        sketchEditor.setGravity(Gravity.TOP | Gravity.START);
        sketchEditor.setTypeface(Typeface.MONOSPACE);
        sketchEditor.setTextSize(12);
        sketchEditor.setPadding(dp(10), dp(10), dp(10), dp(10));
        sketchEditor.setBackground(round(Color.rgb(7, 12, 23), 10, Color.rgb(44, 63, 90), 1));
        sketchEditor.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        sketchEditor.setHorizontallyScrolling(true);
        LinearLayout.LayoutParams editorLp = params(-1, 310); editorLp.topMargin = dp(8); editor.addView(sketchEditor, editorLp);

        LinearLayout help = panel(); page.addView(help, sectionParams());
        help.addView(sectionTitle("Compatibilidad y seguridad"));
        help.addView(text("• Arduino UNO/Nano/Mega y placas ESP32 con puerto USB-serie compatible.\n• Algunos modelos usan CH340, CP210x o USB CDC; hace falta un cable de datos y OTG.\n• El control automático de pines requiere cargar el firmware de esta app. Sin él, el monitor solo envía/recibe texto del programa instalado.\n• GPIO del ESP32 normalmente trabaja a 3.3 V: no conectes señales de 5 V directamente. No conectes tensión de pared a los pines.\n• Los pines disponibles cambian según el modelo. En ESP32-CAM, muchos están ocupados por la cámara.", 12, MUTED, false));

        setContentView(outerScroll);
    }

    private void refreshDrivers() {
        drivers.clear();
        try {
            drivers.addAll(UsbSerialProber.getDefaultProber().findAllDrivers(usbManager));
        } catch (Exception e) {
            appendLog("[USB] Error buscando placas: " + e.getMessage() + "\n");
        }
        List<String> labels = new ArrayList<>();
        for (UsbSerialDriver driver : drivers) {
            UsbDevice d = driver.getDevice();
            String name = d.getProductName();
            if (name == null || name.trim().isEmpty()) name = "USB serial";
            labels.add(name + " · VID " + String.format(Locale.US, "%04X", d.getVendorId()) +
                    " / PID " + String.format(Locale.US, "%04X", d.getProductId()));
        }
        if (labels.isEmpty()) labels.add("No se detectó un puerto serie compatible");
        if (deviceSpinner != null) {
            deviceSpinner.setAdapter(makeSpinnerAdapter(labels.toArray(new String[0])));
        }
        if (deviceSummary != null) {
            deviceSummary.setText(labels.size() > 0 && !drivers.isEmpty()
                    ? drivers.size() + " puerto(s) serie detectado(s). Elige uno y pulsa Conectar."
                    : "No se detectó un puerto compatible. Revisa OTG, el cable de datos y el adaptador USB-serie.");
        }
        appendLog("[USB] Búsqueda terminada: " + drivers.size() + " puerto(s) serie.\n");
    }

    private void connectSelectedDevice() {
        if (serialPort != null) { toast("La placa ya está conectada."); return; }
        if (drivers.isEmpty()) refreshDrivers();
        if (drivers.isEmpty()) {
            toast("No encontré un puerto serie USB compatible.");
            return;
        }
        int selected = deviceSpinner == null ? 0 : deviceSpinner.getSelectedItemPosition();
        if (selected < 0 || selected >= drivers.size()) selected = 0;
        UsbSerialDriver driver = drivers.get(selected);
        if (!usbManager.hasPermission(driver.getDevice())) {
            waitingDriver = driver;
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 31) flags |= PendingIntent.FLAG_MUTABLE;
            PendingIntent permissionIntent = PendingIntent.getBroadcast(this, 0, new Intent(ACTION_USB_PERMISSION), flags);
            usbManager.requestPermission(driver.getDevice(), permissionIntent);
            setStatus("Esperando permiso USB…", BLUE);
            return;
        }
        openDriver(driver);
    }

    private void openDriver(UsbSerialDriver driver) {
        try {
            UsbDeviceConnection connection = usbManager.openDevice(driver.getDevice());
            if (connection == null) {
                toast("Android no pudo abrir el USB. Desconecta y vuelve a conectar.");
                setDisconnectedStatus();
                return;
            }
            List<UsbSerialPort> ports = driver.getPorts();
            if (ports == null || ports.isEmpty()) {
                connection.close();
                toast("El dispositivo no expone un puerto serie compatible.");
                setDisconnectedStatus();
                return;
            }
            serialPort = ports.get(0);
            usbConnection = connection;
            int baud = parseInt(String.valueOf(baudSpinner.getSelectedItem()), 115200);
            serialPort.open(connection);
            serialPort.setParameters(baud, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE);
            try { serialPort.setDTR(true); } catch (IOException ignored) { }
            try { serialPort.setRTS(true); } catch (IOException ignored) { }
            serialIoManager = new SerialInputOutputManager(serialPort, new SerialInputOutputManager.Listener() {
                @Override public void onNewData(byte[] data) {
                    String received = new String(data, StandardCharsets.UTF_8);
                    runOnUiThread(() -> appendLog(received));
                }
                @Override public void onRunError(Exception e) {
                    runOnUiThread(() -> {
                        appendLog("\n[USB] Lectura detenida: " + e.getMessage() + "\n");
                        setStatus("Error de comunicación", Color.rgb(255, 180, 85));
                    });
                }
            });
            serialIoManager.start();
            String board = String.valueOf(boardSpinner.getSelectedItem());
            setStatus("Conectado · " + board, ACCENT);
            connectButton.setText("Conectado");
            appendLog("\n[USB] Conectado a " + driver.getDevice().getDeviceName() + " a " + baud + " baudios.\n");
            appendLog("[TIP] Pulsa PING si cargaste el firmware PlacaControl.\n");
        } catch (Exception e) {
            appendLog("[USB] No se pudo conectar: " + e.getMessage() + "\n");
            toast("Error al abrir el puerto. Revisa el cable, permisos y velocidad.");
            disconnectSerial("Sin conectar");
        }
    }

    private void disconnectSerial(String message) {
        try { if (serialIoManager != null) { serialIoManager.stop(); serialIoManager = null; } } catch (Exception ignored) { }
        try { if (serialPort != null) { serialPort.close(); serialPort = null; } } catch (Exception ignored) { }
        try { if (usbConnection != null) { usbConnection.close(); usbConnection = null; } } catch (Exception ignored) { }
        waitingDriver = null;
        setDisconnectedStatus();
        appendLog("\n[USB] " + message + "\n");
    }

    private void setDisconnectedStatus() {
        setStatus("Estado: sin conectar", MUTED);
        if (connectButton != null) connectButton.setText("Conectar");
    }

    private void setStatus(String message, int color) {
        if (connectionStatus != null) {
            connectionStatus.setText("Estado: " + message);
            connectionStatus.setTextColor(color);
        }
    }

    private void sendPinCommand(String command) {
        if (readPin() < 0) { toast("Escribe un número de pin válido."); return; }
        sendCommand(command);
    }

    private int readPin() {
        return parseInt(pinInput == null ? "" : pinInput.getText().toString().trim(), -1);
    }

    private void sendCommand(String command) {
        if (serialPort == null) { toast("Primero conecta la placa por USB."); return; }
        try {
            String line = command.endsWith("\n") ? command : command + "\n";
            serialPort.write(line.getBytes(StandardCharsets.UTF_8), 1200);
            appendLog(">> " + command.trim() + "\n");
        } catch (Exception e) {
            appendLog("[USB] No se pudo enviar: " + e.getMessage() + "\n");
            toast("Falló el envío. Comprueba la conexión.");
        }
    }

    private void appendLog(String message) {
        if (serialLog == null) return;
        serialLog.append(message);
        int maxChars = 24000;
        if (serialLog.length() > maxChars) {
            CharSequence recent = serialLog.getText().subSequence(serialLog.length() - maxChars / 2, serialLog.length());
            serialLog.setText(recent);
        }
        if (serialLogScroll != null) serialLogScroll.post(() -> serialLogScroll.fullScroll(View.FOCUS_DOWN));
    }

    private void openSketch() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/plain");
        startActivityForResult(intent, REQUEST_OPEN_FILE);
    }

    private void saveSketch() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TITLE, "MiSketch.ino");
        startActivityForResult(intent, REQUEST_SAVE_FILE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQUEST_OPEN_FILE) {
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) throw new IOException("No se pudo abrir el archivo");
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buffer = new byte[4096]; int read;
                while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
                sketchEditor.setText(new String(out.toByteArray(), StandardCharsets.UTF_8));
                toast("Sketch abierto.");
            } catch (Exception e) { toast("No se pudo abrir: " + e.getMessage()); }
        } else if (requestCode == REQUEST_SAVE_FILE) {
            try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null) throw new IOException("No se pudo guardar el archivo");
                out.write(sketchEditor.getText().toString().getBytes(StandardCharsets.UTF_8));
                out.flush();
                toast("Sketch guardado.");
            } catch (Exception e) { toast("No se pudo guardar: " + e.getMessage()); }
        }
    }

    private void loadBoardFirmware() {
        String file = String.valueOf(boardSpinner.getSelectedItem()).startsWith("ESP32")
                ? "ESP32_PlacaControl.ino" : "Arduino_PlacaControl.ino";
        try (InputStream in = getAssets().open(file)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[4096]; int read;
            while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
            sketchEditor.setText(new String(out.toByteArray(), StandardCharsets.UTF_8));
            toast("Firmware cargado al editor. Guárdalo y cárgalo con un IDE compatible.");
            if (String.valueOf(boardSpinner.getSelectedItem()).contains("ESP32-CAM")) {
                toast("ESP32-CAM: verifica pines ocupados por la cámara antes de conectar circuitos.");
            }
        } catch (Exception e) { toast("No se pudo cargar el firmware de ejemplo."); }
    }

    private String serialExample() {
        return "// Ejemplo de comunicación serie para Arduino o ESP32\n" +
                "// Velocidad: 115200 baudios\n\n" +
                "void setup() {\n" +
                "  Serial.begin(115200);\n" +
                "  Serial.println(\"Hola desde la placa\");\n" +
                "}\n\n" +
                "void loop() {\n" +
                "  if (Serial.available()) {\n" +
                "    String mensaje = Serial.readStringUntil('\\n');\n" +
                "    Serial.print(\"Recibido: \" );\n" +
                "    Serial.println(mensaje);\n" +
                "  }\n" +
                "}\n";
    }

    private LinearLayout panel() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(13), dp(13), dp(13), dp(13));
        box.setBackground(round(PANEL, 16, Color.rgb(40, 58, 82), 1));
        return box;
    }

    private TextView sectionTitle(String value) {
        TextView t = text(value, 17, TEXT, true);
        LinearLayout.LayoutParams lp = params(-1, -2); lp.bottomMargin = dp(9);
        t.setLayoutParams(lp);
        return t;
    }

    private TextView label(String value) {
        TextView t = text(value, 12, MUTED, true);
        LinearLayout.LayoutParams lp = params(-1, -2); lp.topMargin = dp(4); lp.bottomMargin = dp(2);
        t.setLayoutParams(lp);
        return t;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private EditText field(String hint, int type) {
        EditText e = new EditText(this);
        e.setSingleLine(true); e.setTextSize(13); e.setTextColor(TEXT); e.setHintTextColor(MUTED);
        e.setHint(hint); e.setInputType(type); e.setPadding(dp(10), 0, dp(10), 0);
        e.setBackground(round(PANEL2, 10, Color.rgb(61, 82, 111), 1));
        return e;
    }

    private Spinner spinner(String[] values) {
        Spinner s = new Spinner(this);
        s.setAdapter(makeSpinnerAdapter(values));
        s.setBackground(round(PANEL2, 10, Color.rgb(61, 82, 111), 1));
        return s;
    }

    private ArrayAdapter<String> makeSpinnerAdapter(String[] values) {
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, values) {
            @Override public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                if (view instanceof TextView) {
                    TextView t = (TextView) view;
                    t.setTextColor(TEXT); t.setTextSize(13); t.setPadding(dp(10), 0, dp(8), 0);
                }
                return view;
            }
            @Override public View getDropDownView(int position, View convertView, ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                if (view instanceof TextView) {
                    TextView t = (TextView) view;
                    t.setTextColor(Color.BLACK); t.setTextSize(14); t.setBackgroundColor(Color.WHITE);
                    t.setPadding(dp(12), dp(9), dp(8), dp(9));
                }
                return view;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        return adapter;
    }

    private Button button(String value, int background, int foreground) {
        Button b = new Button(this);
        b.setText(value); b.setTextSize(11); b.setAllCaps(false); b.setTextColor(foreground);
        b.setPadding(dp(5), 0, dp(5), 0);
        b.setBackground(round(background, 11, background == ACCENT ? ACCENT : background, 1));
        if (Build.VERSION.SDK_INT >= 21) b.setStateListAnimator(null);
        return b;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        return r;
    }

    private GradientDrawable round(int color, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) d.setStroke(dp(strokeDp), strokeColor);
        return d;
    }

    private LinearLayout.LayoutParams params(int width, int height) {
        return new LinearLayout.LayoutParams(width < 0 ? width : dp(width), height < 0 ? height : dp(height));
    }

    private LinearLayout.LayoutParams weightParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(44), 1f);
        p.setMargins(dp(2), 0, dp(2), 0);
        return p;
    }

    private LinearLayout.LayoutParams fieldParams() {
        LinearLayout.LayoutParams p = params(-1, 46); p.bottomMargin = dp(6); return p;
    }

    private LinearLayout.LayoutParams sectionParams() {
        LinearLayout.LayoutParams p = params(-1, -2);
        p.bottomMargin = dp(12);
        return p;
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private int parseInt(String value, int fallback) {
        try { return Integer.parseInt(value.trim()); } catch (Exception e) { return fallback; }
    }
    private void toast(String value) { Toast.makeText(this, value, Toast.LENGTH_LONG).show(); }

    @Override protected void onDestroy() {
        disconnectSerial("App cerrada");
        if (receiverRegistered) {
            try { unregisterReceiver(usbPermissionReceiver); } catch (Exception ignored) { }
            receiverRegistered = false;
        }
        super.onDestroy();
    }
}
