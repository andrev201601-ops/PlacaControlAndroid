/*
  PlacaControl firmware for classic ESP32 DevKit / ESP32-WROOM (Arduino core 2.x/3.x).
  Serial speed: 115200 baud.
  Commands: PING, INFO, HELP, MODE pin IN|OUT|PULLUP, WRITE pin 0|1,
            READ pin, ANALOG gpio, PWM gpio 0..255.

  This is NOT a pin map for every ESP32 variant. ESP32-CAM boards use pins for
  camera/PSRAM and need extra care. Check your exact board pinout before wiring.
  GPIO 6..11 are excluded because they are typically connected to flash on classic ESP32.
  ESP32 GPIO is 3.3 V only; do not apply 5 V to GPIO pins.
*/

String inputLine;

bool validEsp32Pin(int pin) {
  if (pin < 0 || pin > 39) return false;
  if (pin >= 6 && pin <= 11) return false; // internal flash on classic ESP32
  if (pin == 20 || pin == 24 || pin == 28 || pin == 29 || pin == 30 || pin == 31) return false;
  return true;
}

bool outputCapable(int pin) {
  if (!validEsp32Pin(pin)) return false;
  return !(pin >= 34 && pin <= 39); // input-only on classic ESP32
}

bool nextToken(String &remaining, String &out) {
  remaining.trim();
  if (remaining.length() == 0) return false;
  int spaceAt = remaining.indexOf(' ');
  if (spaceAt < 0) { out = remaining; remaining = ""; }
  else { out = remaining.substring(0, spaceAt); remaining = remaining.substring(spaceAt + 1); }
  out.trim();
  return true;
}

void replyError(const String &message) { Serial.print("ERR "); Serial.println(message); }

void processLine(String line) {
  line.trim();
  if (line.length() == 0) return;
  String remaining = line;
  String command, a, b;
  nextToken(remaining, command);
  command.toUpperCase();

  if (command == "PING") { Serial.println("PONG PlacaControl ESP32"); return; }
  if (command == "INFO") { Serial.println("INFO Classic ESP32 DevKit/WROOM serial firmware"); return; }
  if (command == "HELP") {
    Serial.println("CMD PING, INFO, MODE gpio IN|OUT|PULLUP, WRITE gpio 0|1, READ gpio, ANALOG gpio, PWM gpio 0..255");
    return;
  }

  if (command == "MODE") {
    if (!nextToken(remaining, a) || !nextToken(remaining, b)) { replyError("Uso MODE gpio IN|OUT|PULLUP"); return; }
    int pin = a.toInt(); b.toUpperCase();
    if (!validEsp32Pin(pin)) { replyError("GPIO no compatible en este firmware"); return; }
    if (b == "IN") pinMode(pin, INPUT);
    else if (b == "OUT") {
      if (!outputCapable(pin)) { replyError("Este GPIO es solo entrada"); return; }
      pinMode(pin, OUTPUT);
    } else if (b == "PULLUP") pinMode(pin, INPUT_PULLUP);
    else { replyError("Modo desconocido"); return; }
    Serial.print("OK MODE "); Serial.print(pin); Serial.print(' '); Serial.println(b);
    return;
  }

  if (command == "WRITE") {
    if (!nextToken(remaining, a) || !nextToken(remaining, b)) { replyError("Uso WRITE gpio 0|1"); return; }
    int pin = a.toInt(); int value = b.toInt();
    if (!outputCapable(pin) || (value != 0 && value != 1)) { replyError("GPIO o valor no valido para salida"); return; }
    pinMode(pin, OUTPUT); digitalWrite(pin, value ? HIGH : LOW);
    Serial.print("OK WRITE "); Serial.print(pin); Serial.print(' '); Serial.println(value);
    return;
  }

  if (command == "READ") {
    if (!nextToken(remaining, a)) { replyError("Uso READ gpio"); return; }
    int pin = a.toInt();
    if (!validEsp32Pin(pin)) { replyError("GPIO no compatible en este firmware"); return; }
    Serial.print("READ "); Serial.print(pin); Serial.print(' '); Serial.println(digitalRead(pin));
    return;
  }

  if (command == "ANALOG") {
    if (!nextToken(remaining, a)) { replyError("Uso ANALOG gpio"); return; }
    int pin = a.toInt();
    if (!validEsp32Pin(pin)) { replyError("GPIO no compatible en este firmware"); return; }
    Serial.print("ANALOG "); Serial.print(pin); Serial.print(' '); Serial.println(analogRead(pin));
    return;
  }

  if (command == "PWM") {
    if (!nextToken(remaining, a) || !nextToken(remaining, b)) { replyError("Uso PWM gpio 0..255"); return; }
    int pin = a.toInt(); int value = b.toInt();
    if (!outputCapable(pin) || value < 0 || value > 255) { replyError("GPIO o valor PWM no valido"); return; }
    pinMode(pin, OUTPUT);
    analogWrite(pin, value); // supported by current Arduino-ESP32 cores
    Serial.print("OK PWM "); Serial.print(pin); Serial.print(' '); Serial.println(value);
    return;
  }
  replyError("Comando desconocido; envia HELP");
}

void setup() {
  Serial.begin(115200);
  inputLine.reserve(120);
  Serial.println("READY PlacaControl ESP32; envia HELP");
}

void loop() {
  while (Serial.available() > 0) {
    char c = (char)Serial.read();
    if (c == '\r') continue;
    if (c == '\n') { processLine(inputLine); inputLine = ""; }
    else if (inputLine.length() < 120) inputLine += c;
    else { inputLine = ""; replyError("Linea demasiado larga"); }
  }
}
