/*
  PlacaControl firmware for Arduino UNO / Nano / Mega.
  Serial speed: 115200 baud.
  Commands from the Android app:
    PING
    INFO
    HELP
    MODE <pin> IN|OUT|PULLUP
    WRITE <pin> 0|1
    READ <pin>
    ANALOG <channel>  (UNO: 0 means A0)
    PWM <pin> <value 0..255>

  Use numeric pins that exist on your particular Arduino board.
  Do not connect a pin directly to a battery or mains voltage.
*/

String inputLine;

bool validDigitalPin(int pin) {
#if defined(NUM_DIGITAL_PINS)
  return pin >= 0 && pin < NUM_DIGITAL_PINS;
#else
  return pin >= 0 && pin <= 69;
#endif
}

bool nextToken(String &remaining, String &out) {
  remaining.trim();
  if (remaining.length() == 0) return false;
  int spaceAt = remaining.indexOf(' ');
  if (spaceAt < 0) {
    out = remaining;
    remaining = "";
  } else {
    out = remaining.substring(0, spaceAt);
    remaining = remaining.substring(spaceAt + 1);
  }
  out.trim();
  return true;
}

void replyError(const String &message) {
  Serial.print("ERR ");
  Serial.println(message);
}

void processLine(String line) {
  line.trim();
  if (line.length() == 0) return;

  String remaining = line;
  String command, a, b;
  nextToken(remaining, command);
  command.toUpperCase();

  if (command == "PING") {
    Serial.println("PONG PlacaControl Arduino");
    return;
  }
  if (command == "INFO") {
    Serial.println("INFO Arduino-compatible serial firmware");
    return;
  }
  if (command == "HELP") {
    Serial.println("CMD PING, INFO, MODE pin IN|OUT|PULLUP, WRITE pin 0|1, READ pin, ANALOG channel, PWM pin 0..255");
    return;
  }

  if (command == "MODE") {
    if (!nextToken(remaining, a) || !nextToken(remaining, b)) { replyError("Uso MODE pin IN|OUT|PULLUP"); return; }
    int pin = a.toInt();
    b.toUpperCase();
    if (!validDigitalPin(pin)) { replyError("Pin digital fuera de rango para esta placa"); return; }
    if (b == "IN") pinMode(pin, INPUT);
    else if (b == "OUT") pinMode(pin, OUTPUT);
    else if (b == "PULLUP") pinMode(pin, INPUT_PULLUP);
    else { replyError("Modo desconocido"); return; }
    Serial.print("OK MODE "); Serial.print(pin); Serial.print(' '); Serial.println(b);
    return;
  }

  if (command == "WRITE") {
    if (!nextToken(remaining, a) || !nextToken(remaining, b)) { replyError("Uso WRITE pin 0|1"); return; }
    int pin = a.toInt(); int value = b.toInt();
    if (!validDigitalPin(pin) || (value != 0 && value != 1)) { replyError("Pin o valor no valido"); return; }
    pinMode(pin, OUTPUT);
    digitalWrite(pin, value ? HIGH : LOW);
    Serial.print("OK WRITE "); Serial.print(pin); Serial.print(' '); Serial.println(value);
    return;
  }

  if (command == "READ") {
    if (!nextToken(remaining, a)) { replyError("Uso READ pin"); return; }
    int pin = a.toInt();
    if (!validDigitalPin(pin)) { replyError("Pin digital fuera de rango para esta placa"); return; }
    Serial.print("READ "); Serial.print(pin); Serial.print(' '); Serial.println(digitalRead(pin));
    return;
  }

  if (command == "ANALOG") {
    if (!nextToken(remaining, a)) { replyError("Uso ANALOG channel"); return; }
    int channel = a.toInt();
    if (channel < 0 || channel > 31) { replyError("Canal analogico fuera de rango"); return; }
    Serial.print("ANALOG "); Serial.print(channel); Serial.print(' '); Serial.println(analogRead(channel));
    return;
  }

  if (command == "PWM") {
    if (!nextToken(remaining, a) || !nextToken(remaining, b)) { replyError("Uso PWM pin 0..255"); return; }
    int pin = a.toInt(); int value = b.toInt();
    if (!validDigitalPin(pin) || value < 0 || value > 255) { replyError("Pin o PWM fuera de rango"); return; }
    pinMode(pin, OUTPUT);
    analogWrite(pin, value);
    Serial.print("OK PWM "); Serial.print(pin); Serial.print(' '); Serial.println(value);
    return;
  }

  replyError("Comando desconocido; envia HELP");
}

void setup() {
  Serial.begin(115200);
  inputLine.reserve(120);
  pinMode(LED_BUILTIN, OUTPUT);
  Serial.println("READY PlacaControl Arduino; envia HELP");
}

void loop() {
  while (Serial.available() > 0) {
    char c = (char)Serial.read();
    if (c == '\r') continue;
    if (c == '\n') {
      processLine(inputLine);
      inputLine = "";
    } else if (inputLine.length() < 120) {
      inputLine += c;
    } else {
      inputLine = "";
      replyError("Linea demasiado larga");
    }
  }
}
