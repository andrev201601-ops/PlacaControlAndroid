# PlacaControl para Android — Arduino y ESP32

Proyecto Android nativo (Java) con interfaz en español para comunicarse por USB OTG con placas Arduino y ESP32.

## Lo que incluye

- Detección de puertos serie USB que reconozca la biblioteca USB Serial for Android.
- Selección de puerto USB y velocidad serie.
- Monitor serie para ver mensajes y enviar comandos de texto.
- Panel de control rápido para consultar o cambiar pines mediante comandos `MODE`, `READ`, `WRITE`, `ANALOG` y `PWM`.
- Editor de archivos `.ino`: abrir y guardar con el selector de archivos Android.
- Firmware de referencia para Arduino UNO/Nano/Mega y ESP32 clásico DevKit/WROOM, incluido dentro de `firmware/` y en los recursos de la app.
- GitHub Actions para generar un APK de depuración descargable.

## Importante: qué NO hace todavía

Esta versión no es una reproducción completa de Arduino IDE. La app **no compila ni carga sketches desde el propio teléfono**. El editor abre/guarda código, pero para compilar y flashear el firmware debes usar una herramienta compatible, por ejemplo Arduino IDE en una computadora o una versión de ArduinoDroid compatible con tu placa. Después de cargar uno de los firmwares `PlacaControl`, la app puede manejar los pines usando el protocolo serie incluido.

No es posible controlar automáticamente de la misma manera un sketch arbitrario ya instalado: cada sketch define sus propios comandos. Sin el firmware PlacaControl, el monitor serie solamente envía y recibe texto según el programa que ya tenga la placa.

## Placas y conexión

- Arduino UNO/Nano/Mega: el firmware Arduino es una base común, pero los pines disponibles dependen de la placa concreta.
- ESP32 DevKit/WROOM clásico: usa el firmware ESP32 incluido.
- ESP32-CAM: aparece como selección, pero la configuración de pines de la cámara y la forma de programarla dependen del modelo. No uses el firmware a ciegas ni conectes a GPIO que estén ocupados por la cámara.
- Otros ESP32 (S2/S3/C3/C6, etc.) pueden requerir revisar su mapa de pines y su método USB/serie. No se promete compatibilidad universal con todas las variantes.
- El teléfono debe soportar USB host/OTG y usar un cable USB de datos. Algunos teléfonos necesitan un adaptador OTG correcto. La placa también debe aparecer como puerto serie USB compatible; la biblioteca incluye controladores para familias comunes como CH340, CP210x, FTDI y dispositivos USB CDC.

## Uso

1. Conecta la placa al teléfono mediante OTG y un cable de datos.
2. Abre PlacaControl, pulsa **Buscar USB**, elige el dispositivo y pulsa **Conectar**.
3. Selecciona la velocidad correcta. Los firmwares incluidos usan **115200 baudios**.
4. Para habilitar los controles de GPIO, abre el editor, pulsa **Cargar firmware de control**, guarda el archivo `.ino` y cárgalo a la placa con Arduino IDE/ArduinoDroid. No necesitas cargar el firmware para usar el monitor serie con otro sketch.
5. Reconecta y pulsa **Probar comunicación (PING)**. Deberías recibir una respuesta `PONG` si el firmware está instalado y la velocidad es correcta.
6. Introduce el número de pin según tu placa y utiliza los controles.

## Comandos serie admitidos por el firmware de referencia

- `PING` — verifica que responde.
- `INFO` — devuelve información básica.
- `HELP` — enumera los comandos.
- `MODE <pin> IN|OUT|PULLUP` — configura el modo de un pin.
- `WRITE <pin> 0|1` — pone una salida en LOW/HIGH.
- `READ <pin>` — lee un valor digital.
- `ANALOG <canal>` en Arduino o `ANALOG <GPIO>` en ESP32 — devuelve lectura analógica.
- `PWM <pin> <0..255>` — fija PWM en pines compatibles.

## Construir el APK mediante GitHub Actions

Este repositorio incluye `.github/workflows/build-apk.yml`. Después de subir **el contenido de esta carpeta** a un repositorio de GitHub:

1. Abre la pestaña **Actions** del repositorio.
2. Si GitHub pregunta, activa los workflows.
3. Abre **Construir APK de PlacaControl** y pulsa **Run workflow**, o haz un `push` a `main`/`master`.
4. Cuando termine, abre la ejecución y descarga el artefacto **PlacaControl-APK**. Dentro está `app-debug.apk`.
5. Pasa el APK a tu Android e instálalo. Android puede pedir permiso para instalar aplicaciones de esa fuente.

También puedes abrir el proyecto en Android Studio, sincronizar Gradle y ejecutar **Build > Build APK(s)**. El APK de depuración se genera en `app/build/outputs/apk/debug/app-debug.apk`.

## Dependencias de compilación

- Android Gradle Plugin 8.7.3
- Gradle 8.9
- Java 17
- Android SDK Platform 35
- [`usb-serial-for-android`](https://github.com/mik3y/usb-serial-for-android), versión 3.11.0 (licencia MIT)

## Seguridad eléctrica

Usa únicamente circuitos de baja tensión. La mayoría de los GPIO ESP32 son de 3.3 V y no toleran 5 V en la entrada. No conectes tensión de pared a la placa ni uses un pin para alimentar un motor directamente. Para motores usa un controlador/driver adecuado y una fuente apropiada.
